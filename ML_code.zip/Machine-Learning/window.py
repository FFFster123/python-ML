import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
from tkinter.simpledialog import Dialog
import os


# 主窗口
class MainApp:
    def __init__(self, root):
        self.root = root
        self.root.title("抗生素胁迫下人工湿地脱氮的机器学习程序 V1.0")
        self.root.geometry("600x400")

        # 标题
        self.label = tk.Label(root, text="抗生素胁迫下人工湿地脱氮的机器学习程序 V1.0", font=("Times New Roman", 16))
        self.label.pack(pady=20)

        # 点击进入按钮
        self.enter_button = tk.Button(root, text="点击进入", command=self.open_second_window)
        self.enter_button.pack()

    def open_second_window(self):
        self.root.withdraw()  # 隐藏主窗口
        second_window = tk.Toplevel(self.root)
        SecondWindow(second_window, self.root)

# 第二个窗口
class SecondWindow:
    def __init__(self, window, root):
        self.window = window
        self.root = root
        self.window.title("第二个窗口")
        self.window.geometry("700x400")

        # 创建 Canvas 用于绘制按钮和箭头
        self.canvas = tk.Canvas(self.window, width=600, height=200)
        self.canvas.pack()

        folder_path = 'Codes'

        # 按钮标签和对应文本文件名的映射
        self.button_to_file = {
            "数据收集": os.path.join(folder_path,"data_collection.txt"),
            "数据上传": os.path.join(folder_path,"data_upload.txt"),
            "数据分析与统计": os.path.join(folder_path,"data_analysis.txt"),
            "数据预处理": os.path.join(folder_path,"data_preprocessing.txt"),
            "皮尔逊相关性分析": os.path.join(folder_path,"pearson_correlation.txt")
        }

        # 五个按钮（A, B, C, D, E）
        self.buttons = []
        button_labels = [
            "数据收集", "数据上传", "数据分析与统计",
            "数据预处理", "皮尔逊相关性分析"
        ]

        for i, label in enumerate(self.button_to_file.keys()):
            button = tk.Button(self.window, text=label,
                               command=lambda label=label: self.open_text_file(self.button_to_file[label]))
            self.buttons.append(button)
            x = 40 + i * 105
            y = 50
            self.canvas.create_window(x, y, window=button)

            if i < 5:
                self.canvas.create_line(x + 4, y, x + 120, y, arrow=tk.LAST)

        button1 = tk.Button(self.window, text="机器学习分析", command=self.open_third_window)
        button1.pack(pady=10)

    def open_text_file(self, filename):
        # 打开一个对话框来显示文本文件内容
        class TextViewer(Dialog):
            def __init__(self, parent, title, filename):
                self.filename = filename
                super().__init__(parent, title=title)

            def body(self, master):
                self.text = scrolledtext.ScrolledText(master, wrap=tk.WORD, width=80, height=20)
                self.text.pack(padx=10, pady=10)
                self.load_text()
                return self.text

            def load_text(self):
                try:
                    with open(self.filename, 'r', encoding='utf-8') as file:
                        self.text.delete(1.0, tk.END)  # 清空文本框内容
                        self.text.insert(tk.END, file.read())  # 插入文件内容
                except FileNotFoundError:
                    messagebox.showerror("错误", f"文件 {self.filename} 未找到！")

        # 创建并显示文本查看器对话框
        TextViewer(self.window, title=f"查看 {filename}", filename=filename)


    def update_text_box(self, text):
        self.text_box.delete(1.0, tk.END)  # 清空文本框内容
        self.text_box.insert(tk.END, text)  # 插入新的文本内容

    def handle_button_click(self, button_number):
        if button_number == 6:
            self.open_third_window()

    def open_third_window(self):
        self.window.withdraw()  # 隐藏第二个窗口
        third_window = tk.Toplevel(self.window)
        ThirdWindow(third_window, self.root)

# 第三个窗口
class ThirdWindow:
    def __init__(self, window, root):
        self.window = window
        self.root = root
        self.window.title("第三个窗口")
        self.window.geometry("300x200")

        # 三个按钮
        button1 = tk.Button(self.window, text="运行RF", command=self.open_fourth_window)
        button1.pack(pady=10)

        button2 = tk.Button(self.window, text="运行XGB",command=self.open_sixth_window)
        button2.pack(pady=10)

        button3 = tk.Button(self.window, text="模型评估",command=self.open_eighth_window)
        button3.pack(pady=10)

    def open_fourth_window(self):
        self.window.withdraw()  # 隐藏第三个窗口
        fourth_window = tk.Toplevel(self.window)
        FourthWindow(fourth_window, self.root)

    def open_sixth_window(self):
        self.window.withdraw()  # 隐藏第三个窗口
        sixth_window = tk.Toplevel(self.window)
        SixthWindow(sixth_window, self.root)

    def open_eighth_window(self):
        self.window.withdraw()  # 隐藏第三个窗口
        eighth_window = tk.Toplevel(self.window)
        EighthWindow(eighth_window, self.root)


# 第四个窗口
class FourthWindow:
    def __init__(self, window, root):
        self.window = window
        self.root = root
        self.window.title("第四个窗口")
        self.window.geometry("300x200")

        button2 = tk.Button(self.window, text="确认运行RF", command=self.open_fifth_window)
        button2.pack(pady=10)

    def open_fifth_window(self):
        self.window.withdraw()  # 隐藏第四个窗口
        fifth_window = tk.Toplevel(self.window)
        FifthWindow(fifth_window, self.root)

# 第五个窗口
class FifthWindow:
    def __init__(self, window, root):
        self.window = window
        self.root = root
        self.window.title("第五个窗口")
        self.window.geometry("600x400")

        # 创建 Canvas 用于绘制按钮和箭头
        self.canvas = tk.Canvas(self.window, width=600, height=200)
        self.canvas.pack()

        folder_path = 'Codes'

        # 按钮标签和对应文本文件名的映射
        self.button_to_file = {
            "超参数优化": os.path.join(folder_path,"RF_hyperparameter_optimization.txt"),
            "线性拟合": os.path.join(folder_path,"RF_linear_firring.txt"),
            "评估得分": os.path.join(folder_path,"Rf_evaluation_score.txt"),
            "TFI": os.path.join(folder_path,"RF_TFI.txt"),
            "SHAP": os.path.join(folder_path,"RF_Shapley.txt")
        }

        # 五个按钮（A, B, C, D, E）
        self.buttons = []
        button_labels = [
            "超参数优化", "线性拟合", "评估得分",
            "TFI", "SHAP"
        ]

        for i, label in enumerate(self.button_to_file.keys()):
            button = tk.Button(self.window, text=label,
                               command=lambda label=label: self.open_text_file(self.button_to_file[label]))
            self.buttons.append(button)
            x = 50 + i * 90
            y = 50
            self.canvas.create_window(x, y, window=button)

            if i < 5:
                self.canvas.create_line(x + 10, y, x + 90, y, arrow=tk.LAST)

        button1 = tk.Button(self.window, text="上一页", command=self.open_third_window)
        button1.pack(pady=10)

    def open_text_file(self, filename):
        # 打开一个对话框来显示文本文件内容
        class TextViewer(Dialog):
            def __init__(self, parent, title, filename):
                self.filename = filename
                super().__init__(parent, title=title)

            def body(self, master):
                self.text = scrolledtext.ScrolledText(master, wrap=tk.WORD, width=80, height=20)
                self.text.pack(padx=10, pady=10)
                self.load_text()
                return self.text

            def load_text(self):
                try:
                    with open(self.filename, 'r', encoding='utf-8') as file:
                        self.text.delete(1.0, tk.END)  # 清空文本框内容
                        self.text.insert(tk.END, file.read())  # 插入文件内容
                except FileNotFoundError:
                    messagebox.showerror("错误", f"文件 {self.filename} 未找到！")

        # 创建并显示文本查看器对话框
        TextViewer(self.window, title=f"查看 {filename}", filename=filename)

    def update_text_box(self, text):
        self.text_box.delete(1.0, tk.END)  # 清空文本框内容
        self.text_box.insert(tk.END, text)  # 插入新的文本内容

    def open_third_window(self):
        self.window.withdraw()  # 隐藏第二个窗口
        third_window = tk.Toplevel(self.window)
        ThirdWindow(third_window, self.root)


class SixthWindow:
    def __init__(self, window, root):
        self.window = window
        self.root = root
        self.window.title("第六个窗口")
        self.window.geometry("300x200")

        button2 = tk.Button(self.window, text="确认运行XGB", command=self.open_seventh_window)
        button2.pack(pady=10)

    def open_seventh_window(self):
        self.window.withdraw()  # 隐藏第六个窗口
        seventh_window = tk.Toplevel(self.window)
        SeventhWindow(seventh_window, self.root)

# 第七个窗口
class SeventhWindow:
    def __init__(self, window, root):
        self.window = window
        self.root = root
        self.window.title("第七个窗口")
        self.window.geometry("600x400")

        # 创建 Canvas 用于绘制按钮和箭头
        self.canvas = tk.Canvas(self.window, width=600, height=200)
        self.canvas.pack()

        folder_path = 'Codes'

        # 按钮标签和对应文本文件名的映射
        self.button_to_file = {
            "超参数优化": os.path.join(folder_path,"XGB_hyperparameter_optimization.txt"),
            "线性拟合": os.path.join(folder_path,"XGB_linear_firring.txt"),
            "评估得分": os.path.join(folder_path,"XGB_evaluation_score.txt"),
            "TFI": os.path.join(folder_path,"XGB_TFI.txt"),
            "SHAP": os.path.join(folder_path,"XGB_Shapley.txt")
        }

        # 五个按钮（A, B, C, D, E）
        self.buttons = []
        button_labels = [
            "超参数优化", "线性拟合", "评估得分",
            "TFI", "SHAP"
        ]

        for i, label in enumerate(self.button_to_file.keys()):
            button = tk.Button(self.window, text=label,
                               command=lambda label=label: self.open_text_file(self.button_to_file[label]))
            self.buttons.append(button)
            x = 50 + i * 90
            y = 50
            self.canvas.create_window(x, y, window=button)

            if i < 5:
                self.canvas.create_line(x + 10, y, x + 90, y, arrow=tk.LAST)

        button1 = tk.Button(self.window, text="上一页", command=self.open_third_window)
        button1.pack(pady=10)

    def open_text_file(self, filename):
        # 打开一个对话框来显示文本文件内容
        class TextViewer(Dialog):
            def __init__(self, parent, title, filename):
                self.filename = filename
                super().__init__(parent, title=title)

            def body(self, master):
                self.text = scrolledtext.ScrolledText(master, wrap=tk.WORD, width=80, height=20)
                self.text.pack(padx=10, pady=10)
                self.load_text()
                return self.text

            def load_text(self):
                try:
                    with open(self.filename, 'r', encoding='utf-8') as file:
                        self.text.delete(1.0, tk.END)  # 清空文本框内容
                        self.text.insert(tk.END, file.read())  # 插入文件内容
                except FileNotFoundError:
                    messagebox.showerror("错误", f"文件 {self.filename} 未找到！")

        # 创建并显示文本查看器对话框
        TextViewer(self.window, title=f"查看 {filename}", filename=filename)

    def update_text_box(self, text):
        self.text_box.delete(1.0, tk.END)  # 清空文本框内容
        self.text_box.insert(tk.END, text)  # 插入新的文本内容

    def open_third_window(self):
        self.window.withdraw()  # 隐藏第二个窗口
        third_window = tk.Toplevel(self.window)
        ThirdWindow(third_window, self.root)

class EighthWindow:
    def __init__(self, window, root):
        self.window = window
        self.root = root
        self.window.title("第八个窗口")
        self.window.geometry("300x200")

        # 创建一个按钮用于显示文本文件
        self.show_file_button = tk.Button(self.window, text="开始模型评估", command=self.open_text_file)
        self.show_file_button.pack(pady=20)

        # 创建一个按钮用于返回到第三个窗口
        self.back_button = tk.Button(self.window, text="上一页", command=self.open_third_window)
        self.back_button.pack(pady=10)

    def open_text_file(self):
        # 定义要显示的文本文件的路径
        filename = "model_evaluation.txt"  # 替换为您的实际文件名

        # 打开一个对话框来显示文本文件内容
        class  TextViewer(Dialog):
            def __init__(self, parent, title, filename):
                self.filename = filename
                super().__init__(parent, title=title)

            def body(self, master):
                self.text = scrolledtext.ScrolledText(master, wrap=tk.WORD, width=80, height=20)
                self.text.pack(padx=10, pady=10)
                self.load_text()
                return self.text

            def load_text(self):
                try:
                    with open(self.filename, 'r', encoding='utf-8') as file:
                        self.text.delete(1.0, tk.END)  # 清空文本框内容
                        self.text.insert(tk.END, file.read())  # 插入文件内容
                except FileNotFoundError:
                    messagebox.showerror("错误", f"文件 {self.filename} 未找到！")

                    # 创建并显示文本查看器对话框

        TextViewer(self.window, title=f"查看 {filename}", filename=filename)

    def open_third_window(self):
        self.window.withdraw()  # 隐藏第二个窗口
        third_window = tk.Toplevel(self.window)
        ThirdWindow(third_window, self.root)

if __name__ == "__main__":
    root = tk.Tk()
    app = MainApp(root)
    root.mainloop()
