import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
from tkinter import ttk
from tkinter.simpledialog import Dialog
import os
import subprocess
import platform
from PIL import Image
from tkinter import Tk, Toplevel, Label, messagebox
from PIL import ImageTk
from PIL import ImageSequence

# 主窗口
class MainApp:
    def __init__(self, root):
        self.root = root
        self.root.title("抗生素胁迫下人工湿地脱氮的机器学习程序 V1.0")
        self.root.geometry("600x400")

        # 标题
        self.label = tk.Label(root, text="抗生素胁迫下人工湿地脱氮的机器学习程序 V1.0", font=("Times New Roman", 16))
        self.label.pack(pady=20)

        # 点击进入按钮
        self.enter_button = tk.Button(root, text="点击进入", command=self.open_second_window)
        self.enter_button.pack()

    def open_second_window(self):
        self.root.withdraw()  # 隐藏主窗口
        second_window = tk.Toplevel(self.root)
        SecondWindow(second_window, self.root)

# 第二个窗口
class SecondWindow:
    def __init__(self, window, root):
        self.window = window
        self.root = root
        self.window.title("文件上传")
        self.window.geometry("330x200")

        # 文件选择下拉框
        self.file_var = tk.StringVar()
        self.file_menu = ttk.Combobox(self.window, textvariable=self.file_var, state='readonly', width=30)
        self.file_menu.grid(row=0, column=0, padx=10, pady=10, sticky='ew')
        self.populate_file_menu()

        tk.Label(self.window, text="").grid(row=1, column=1, padx=10, pady=5)

        # 浏览按钮
        self.browse_button = tk.Button(self.window, text="浏览", command=self.browse_file)
        self.browse_button.grid(row=0, column=1, padx=15, pady=10, sticky='w')

        # 确认上传按钮
        self.confirm_button = tk.Button(self.window, text="确认上传数据文件", command=self.confirm_upload)
        self.confirm_button.grid(row=2, column=0, columnspan=2, padx=10, pady=10)

        # 数据分析按钮
        self.analyze_button = tk.Button(self.window, text="数据分析", command=self.analyze_data)
        self.analyze_button.grid(row=3, column=0, columnspan=2, padx=10, pady=10)

        self.selected_file = None
    def populate_file_menu(self):
        pass

    def browse_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx"), ("CSV files", "*.csv")])
        if file_path:
            self.file_var.set(os.path.basename(file_path))
            self.selected_file = file_path

    def confirm_upload(self):
        if self.selected_file:
            messagebox.showinfo("上传成功", "文件上传成功！")
        else:
            messagebox.showwarning("警告", "请先选择一个文件！")

    def analyze_data(self):
        if self.selected_file:
            # 创建并显示第三个窗口
            self.third_window = ThirdWindow(self.window, self.root)
            self.window.withdraw()  # 隐藏当前窗口
        else:
            messagebox.showwarning("警告", "请先选择一个文件！")

# 第三个窗口
class ThirdWindow(tk.Toplevel):
    def __init__(self, window, root):
        super().__init__(root)
        self.root = root
        self.title("数据统计与分析")
        self.geometry("400x200")

        # 使用grid方法布局按钮
        self.statistics_button = tk.Button(self, text="数据统计")
        self.statistics_button.grid(row=0, column=0, columnspan=2, padx=60, pady=10)
        self.statistics_button.config(command=lambda: self.show_statistics("DATA_Box\Boxphoto"))

        self.correlation_button = tk.Button(self, text="皮尔逊相关性分析")
        self.correlation_button.grid(row=0, column=2, columnspan=2, padx=60, pady=10)
        self.correlation_button.config(command=lambda: self.show_correlation("Pearson"))

        self.machine_learning_button = tk.Button(self, text="机器学习分析")
        self.machine_learning_button.grid(row=2, column=1, columnspan=2, padx=60, pady=10)
        self.machine_learning_button.config(command=self.open_sixth_window)

    def show_statistics(self, directory):
        # 弹出 DATA_Box 文件夹（这里使用平台特定的方法）
        parent_directory = os.path.dirname(directory)  # 获取 DATA_Box 文件夹路径
        if platform.system() == "Windows":
            os.startfile(parent_directory)  # 在Windows上打开文件夹
        else:
            open_command = {"Linux": ["xdg-open", parent_directory], "Darwin": ["open", parent_directory]}[
                platform.system()]
            subprocess.Popen(open_command)
            # 创建并显示 FourthWindow 实例以展示 Boxphoto 文件夹中的图片
        FourthWindow(self, directory)

    def show_correlation(self, directory2):
        if platform.system() == "Windows":
            os.startfile(directory2)
        else:
            open_command = {"Linux": ["xdg-open", directory2], "Darwin": ["open", directory2]}[
                platform.system()]
            subprocess.Popen(open_command)
        FifthWindow(self, directory2)

    def open_sixth_window(self):
        self.withdraw()
        sixth_window = SixthWindow(self.root)

    # 第四个窗口(箱线图)
class FourthWindow(tk.Toplevel):
        def __init__(self, root, image_directory):
            super().__init__(root)
            self.title("箱线图与数据分布")
            self.geometry("800x600")

            # 创建一个Canvas和一个Scrollbar
            self.canvas = tk.Canvas(self)
            self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
            self.canvas.configure(yscrollcommand=self.scrollbar.set)

            # 将Scrollbar和Canvas打包到窗口中
            self.scrollbar.pack(side="right", fill="y")
            self.canvas.pack(side="left", fill="both", expand=True)

            # 创建一个可滚动的Frame（实际上是一个Canvas窗口项）
            self.scrollable_frame = ttk.Frame(self.canvas)
            self.canvas_frame = self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor='nw')

            # 更新Canvas的可滚动区域
            self.update_idletasks()
            self.canvas.configure(scrollregion=self.canvas.bbox("all"))

            # 绑定Canvas的滚动事件
            self.canvas.bind("<Configure>", self.on_canvas_configure)

            # 加载和显示图片
            self.load_images(image_directory)

        def load_images(self, image_directory):
            self.row = 0
            self.col = 0

            # 获取指定文件夹中所有符合条件的图片文件
            image_files = [f for f in os.listdir(image_directory) if
                           f.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff'))]
            image_paths = [os.path.join(image_directory, f) for f in image_files]

            for image_path in image_paths:
                try:
                    # 打开图片并调整大小（如果需要）
                    image = Image.open(image_path)
                    image.thumbnail((200, 200))  # 调整图片大小

                    # 转换为tkinter可以显示的格式
                    photo = ImageTk.PhotoImage(image)

                    # 创建一个Label控件来显示图片，并添加到scrollable_frame中
                    label = ttk.Label(self.scrollable_frame, image=photo)
                    label.image = photo  # 保持对PhotoImage的引用，防止被垃圾回收
                    label.grid(row=self.row, column=self.col, padx=10, pady=10)

                    # 更新行列索引
                    self.col += 1
                    if self.col >= 4:  # 每行显示4张图片
                        self.col = 0
                        self.row += 1

                        # 更新Canvas的可滚动区域（每次添加图片后）
                    self.update_idletasks()
                    self.canvas.configure(scrollregion=self.canvas.bbox("all"))

                except Exception as e:
                    # 显示错误消息框
                    messagebox.showerror("图片加载错误", f"无法加载图片 {image_path}：{e}")

        def on_canvas_configure(self, event):
            canvas_width = event.width
            frame_height = (self.row + 1) * (200 + 20)  # 200是图片高度，20是 pady 的总和（上下各10）
            self.canvas.itemconfig(self.canvas_frame, width=canvas_width, height=frame_height)

# 第五个窗口(皮尔逊相关性图)
class FifthWindow(tk.Toplevel):
    def __init__(self, root, image_directory):
        super().__init__(root)
        self.title("皮尔逊相关性分析")
        self.geometry("900x800")

        self.row = 0
        self.col = 0

        # 获取指定文件夹中所有符合条件的图片文件
        image_files = [f for f in os.listdir(image_directory) if f.lower().endswith(('.png', '.tif'))]
        image_paths = [os.path.join(image_directory, f) for f in image_files]

        for image_path in image_paths:
            try:
                # 打开图片并调整大小（如果需要）
                image = Image.open(image_path)
                image.thumbnail((800, 800))  # 这里将图片大小调整为200x200，您可以根据需要调整

                # 转换为tkinter可以显示的格式
                photo = ImageTk.PhotoImage(image)

                # 创建一个Label控件来显示图片，并使用grid布局
                label = ttk.Label(self, image=photo)
                label.image = photo  # 保持对PhotoImage的引用，防止被垃圾回收
                label.grid(row=self.row, column=self.col, padx=10, pady=10)

                # 更新行列索引
                self.col += 1
                if self.col >= 4:  # 这里设置每行显示4张图片，您可以根据需要调整
                    self.col = 0
                    self.row += 1

            except Exception as e:
                # 显示错误消息框
                messagebox.showerror("图片加载错误", f"无法加载图片 {image_path}：{e}")

    # 第六个窗口（选择机器学习模型）
class SixthWindow(tk.Toplevel):
    def __init__(self, root):
        super().__init__(root)
        self.root = root
        self.title("机器学习分析")
        self.geometry("450x250")

        self.RF_button = tk.Button(self, text="运行RandomForest")
        self.RF_button.grid(row=1, column=0, columnspan=2, padx=60, pady=10)
        self.RF_button.config(command=lambda: self.show_RandomForest("RandomForest\LinearFitting"))

        self.XGB_button = tk.Button(self, text="运行XGBoost")
        self.XGB_button.grid(row=1, column=2, columnspan=2, padx=60, pady=10)
        self.XGB_button.config(command=lambda: self.show_XGBoost("XGBoost\LinearFitting"))

        self.model_evaluation_button = tk.Button(self, text="模型评估")
        self.model_evaluation_button.grid(row=3, column=0, columnspan=2, padx=60, pady=10)
        self.model_evaluation_button.config(command=lambda: self.show_model_evaluation("ModelEvaluation\BarPlot"))

        self.microbiological_analysis_button = tk.Button(self, text="微生物贡献度分析")
        self.microbiological_analysis_button.grid(row=3, column=2, columnspan=2, padx=60, pady=10)
        self.microbiological_analysis_button.config(command=self.open_tenth_window)

    def show_RandomForest(self, directory):
        parent_directory = os.path.dirname(directory)  # 获取文件夹路径
        if platform.system() == "Windows":
            os.startfile(parent_directory)  # 在Windows上打开文件夹
        else:
            open_command = {"Linux": ["xdg-open", parent_directory], "Darwin": ["open", parent_directory]}[
                platform.system()]
            subprocess.Popen(open_command)
            # 创建并显示 FourthWindow 实例以展示 Boxphoto 文件夹中的图片
        SeventhWindow(self, directory)

    def show_XGBoost(self, directory2):
        parent_directory = os.path.dirname(directory2)  # 获取文件夹路径
        if platform.system() == "Windows":
            os.startfile(parent_directory)  # 在Windows上打开文件夹
        else:
            open_command = {"Linux": ["xdg-open", parent_directory], "Darwin": ["open", parent_directory]}[
                platform.system()]
            subprocess.Popen(open_command)
        EighthWindow(self, directory2)

    def show_model_evaluation(self, directory3):
        parent_directory = os.path.dirname(directory3)  # 获取文件夹路径
        if platform.system() == "Windows":
            os.startfile(parent_directory)  # 在Windows上打开文件夹
        else:
            open_command = {"Linux": ["xdg-open", parent_directory], "Darwin": ["open", parent_directory]}[
                platform.system()]
            subprocess.Popen(open_command)
        NinthWindow(self, directory3)

    def open_tenth_window(self):
        self.withdraw()
        tenth_window = TenthWindow(self.root)

# 第七个窗口（RandomForest）
class SeventhWindow(tk.Toplevel):
    def __init__(self, root, image_directory):
        super().__init__(root)
        self.title("RandomForest")
        self.geometry("1800x900")

        self.row = 0
        self.col = 0

        # 获取指定文件夹中所有符合条件的图片文件
        image_files = [f for f in os.listdir(image_directory) if f.lower().endswith(('.png', '.tif'))]
        image_paths = [os.path.join(image_directory, f) for f in image_files]

        for image_path in image_paths:
            try:
                # 打开图片并调整大小（如果需要）
                image = Image.open(image_path)
                image.thumbnail((400, 400))  # 这里将图片大小调整为200x200，您可以根据需要调整

                # 转换为tkinter可以显示的格式
                photo = ImageTk.PhotoImage(image)

                # 创建一个Label控件来显示图片，并使用grid布局
                label = ttk.Label(self, image=photo)
                label.image = photo  # 保持对PhotoImage的引用，防止被垃圾回收
                label.grid(row=self.row, column=self.col, padx=10, pady=10)

                # 更新行列索引
                self.col += 1
                if self.col >= 4:  # 这里设置每行显示4张图片，您可以根据需要调整
                    self.col = 0
                    self.row += 1

            except Exception as e:
                # 显示错误消息框
                messagebox.showerror("图片加载错误", f"无法加载图片 {image_path}：{e}")

# 第八个窗口（XGBoost）
class EighthWindow(tk.Toplevel):
    def __init__(self, root, image_directory):
        super().__init__(root)
        self.title("XGBoost")
        self.geometry("1800x900")

        self.row = 0
        self.col = 0

        # 获取指定文件夹中所有符合条件的图片文件
        image_files = [f for f in os.listdir(image_directory) if f.lower().endswith(('.png', '.tif'))]
        image_paths = [os.path.join(image_directory, f) for f in image_files]

        for image_path in image_paths:
            try:
                # 打开图片并调整大小（如果需要）
                image = Image.open(image_path)
                image.thumbnail((400, 400))  # 这里将图片大小调整为200x200，您可以根据需要调整

                # 转换为tkinter可以显示的格式
                photo = ImageTk.PhotoImage(image)

                # 创建一个Label控件来显示图片，并使用grid布局
                label = ttk.Label(self, image=photo)
                label.image = photo  # 保持对PhotoImage的引用，防止被垃圾回收
                label.grid(row=self.row, column=self.col, padx=10, pady=10)

                # 更新行列索引
                self.col += 1
                if self.col >= 4:  # 这里设置每行显示4张图片，您可以根据需要调整
                    self.col = 0
                    self.row += 1

            except Exception as e:
                # 显示错误消息框
                messagebox.showerror("图片加载错误", f"无法加载图片 {image_path}：{e}")

# 第九个窗口（模型评估）
class NinthWindow(tk.Toplevel):
    def __init__(self, root, image_directory):
        super().__init__(root)
        self.title("模型评估")
        self.geometry("800x600")

        self.row = 0
        self.col = 0

        # 获取指定文件夹中所有符合条件的图片文件
        image_files = [f for f in os.listdir(image_directory) if f.lower().endswith(('.png', '.tif'))]
        image_paths = [os.path.join(image_directory, f) for f in image_files]

        for image_path in image_paths:
            try:
                # 打开图片并调整大小（如果需要）
                image = Image.open(image_path)
                image.thumbnail((800, 800))  # 这里将图片大小调整为200x200，您可以根据需要调整

                # 转换为tkinter可以显示的格式
                photo = ImageTk.PhotoImage(image)

                # 创建一个Label控件来显示图片，并使用grid布局
                label = ttk.Label(self, image=photo)
                label.image = photo  # 保持对PhotoImage的引用，防止被垃圾回收
                label.grid(row=self.row, column=self.col, padx=10, pady=10)

                # 更新行列索引
                self.col += 1
                if self.col >= 4:  # 这里设置每行显示4张图片，您可以根据需要调整
                    self.col = 0
                    self.row += 1

            except Exception as e:
                # 显示错误消息框
                messagebox.showerror("图片加载错误", f"无法加载图片 {image_path}：{e}")

# 第十个窗口（微生物贡献分析）
class TenthWindow(tk.Toplevel):
    def __init__(self, root):
        super().__init__(root)
        self.title("微生物贡献分析")
        self.geometry("350x250")

        self.RA_button = tk.Button(self, text="R(A)")
        self.RA_button.grid(row=1, column=0, columnspan=2, padx=60, pady=10)
        self.RA_button.config(command=lambda: self.show_RA("microorganism\R(A)"))

        self.RB_button = tk.Button(self, text="R(B)")
        self.RB_button.grid(row=1, column=2, columnspan=2, padx=60, pady=10)
        self.RB_button.config(command=lambda: self.show_RB("microorganism\R(B)"))

        self.Rf_button = tk.Button(self, text="R(F)")
        self.Rf_button.grid(row=3, column=0, columnspan=2, padx=60, pady=10)
        self.Rf_button.config(command=lambda: self.show_RF("microorganism\R(F)"))

        self.RP_button = tk.Button(self, text="R(P)")
        self.RP_button.grid(row=3, column=2, columnspan=2, padx=60, pady=10)
        self.RP_button.config(command=lambda: self.show_RP("microorganism\R(P)"))

    def show_RA(self, directory):
        parent_directory = os.path.dirname(directory)  # 获取文件夹路径
        if platform.system() == "Windows":
            os.startfile(parent_directory)  # 在Windows上打开文件夹
        else:
            open_command = {"Linux": ["xdg-open", parent_directory], "Darwin": ["open", parent_directory]}[
                platform.system()]
            subprocess.Popen(open_command)
            # 创建并显示 FourthWindow 实例以展示 Boxphoto 文件夹中的图片
        EleventhWindow(self, directory)

    def show_RB(self, directory2):
        parent_directory = os.path.dirname(directory2)  # 获取文件夹路径
        if platform.system() == "Windows":
            os.startfile(parent_directory)  # 在Windows上打开文件夹
        else:
            open_command = {"Linux": ["xdg-open", parent_directory], "Darwin": ["open", parent_directory]}[
                platform.system()]
            subprocess.Popen(open_command)
        TwelfthWindow(self, directory2)

    def show_RF(self, directory3):
        parent_directory = os.path.dirname(directory3)  # 获取文件夹路径
        if platform.system() == "Windows":
            os.startfile(parent_directory)  # 在Windows上打开文件夹
        else:
            open_command = {"Linux": ["xdg-open", parent_directory], "Darwin": ["open", parent_directory]}[
                platform.system()]
            subprocess.Popen(open_command)
        ThirteenthWindow(self, directory3)

    def show_RP(self, directory4):
        parent_directory = os.path.dirname(directory4)  # 获取文件夹路径
        if platform.system() == "Windows":
            os.startfile(parent_directory)  # 在Windows上打开文件夹
        else:
            open_command = {"Linux": ["xdg-open", parent_directory], "Darwin": ["open", parent_directory]}[
                platform.system()]
            subprocess.Popen(open_command)
        FourteenthWindow(self, directory4)

# 第十一个窗口（R(A)）
class EleventhWindow(tk.Toplevel):
    def __init__(self, root, image_directory):
        super().__init__(root)
        self.title("R(A))")
        self.geometry("1350x900")

        self.row = 0
        self.col = 0

        # 获取指定文件夹中所有符合条件的图片文件
        image_files = [f for f in os.listdir(image_directory) if f.lower().endswith(('.png', '.tif'))]
        image_paths = [os.path.join(image_directory, f) for f in image_files]

        for image_path in image_paths:
            try:
                # 打开图片并调整大小（如果需要）
                image = Image.open(image_path)
                image.thumbnail((400, 400))  # 这里将图片大小调整为200x200，您可以根据需要调整

                # 转换为tkinter可以显示的格式
                photo = ImageTk.PhotoImage(image)

                # 创建一个Label控件来显示图片，并使用grid布局
                label = ttk.Label(self, image=photo)
                label.image = photo  # 保持对PhotoImage的引用，防止被垃圾回收
                label.grid(row=self.row, column=self.col, padx=10, pady=10)

                # 更新行列索引
                self.col += 1
                if self.col >= 3:  # 这里设置每行显示4张图片，您可以根据需要调整
                    self.col = 0
                    self.row += 1

            except Exception as e:
                # 显示错误消息框
                messagebox.showerror("图片加载错误", f"无法加载图片 {image_path}：{e}")

# 第12个窗口（R(B)）
class TwelfthWindow(tk.Toplevel):
    def __init__(self, root, image_directory):
        super().__init__(root)
        self.title("R(B))")
        self.geometry("1350x900")

        self.row = 0
        self.col = 0

        # 获取指定文件夹中所有符合条件的图片文件
        image_files = [f for f in os.listdir(image_directory) if f.lower().endswith(('.png', '.tif'))]
        image_paths = [os.path.join(image_directory, f) for f in image_files]

        for image_path in image_paths:
            try:
                # 打开图片并调整大小（如果需要）
                image = Image.open(image_path)
                image.thumbnail((400, 400))  # 这里将图片大小调整为200x200，您可以根据需要调整

                # 转换为tkinter可以显示的格式
                photo = ImageTk.PhotoImage(image)

                # 创建一个Label控件来显示图片，并使用grid布局
                label = ttk.Label(self, image=photo)
                label.image = photo  # 保持对PhotoImage的引用，防止被垃圾回收
                label.grid(row=self.row, column=self.col, padx=10, pady=10)

                # 更新行列索引
                self.col += 1
                if self.col >= 3:  # 这里设置每行显示4张图片，您可以根据需要调整
                    self.col = 0
                    self.row += 1

            except Exception as e:
                # 显示错误消息框
                messagebox.showerror("图片加载错误", f"无法加载图片 {image_path}：{e}")

# 第13个窗口（R(F)）
class ThirteenthWindow(tk.Toplevel):
    def __init__(self, root, image_directory):
        super().__init__(root)
        self.title("R(A))")
        self.geometry("1350x900")

        self.row = 0
        self.col = 0

        # 获取指定文件夹中所有符合条件的图片文件
        image_files = [f for f in os.listdir(image_directory) if f.lower().endswith(('.png', '.tif'))]
        image_paths = [os.path.join(image_directory, f) for f in image_files]

        for image_path in image_paths:
            try:
                # 打开图片并调整大小（如果需要）
                image = Image.open(image_path)
                image.thumbnail((400, 400))  # 这里将图片大小调整为200x200，您可以根据需要调整

                # 转换为tkinter可以显示的格式
                photo = ImageTk.PhotoImage(image)

                # 创建一个Label控件来显示图片，并使用grid布局
                label = ttk.Label(self, image=photo)
                label.image = photo  # 保持对PhotoImage的引用，防止被垃圾回收
                label.grid(row=self.row, column=self.col, padx=10, pady=10)

                # 更新行列索引
                self.col += 1
                if self.col >= 3:  # 这里设置每行显示4张图片，您可以根据需要调整
                    self.col = 0
                    self.row += 1

            except Exception as e:
                # 显示错误消息框
                messagebox.showerror("图片加载错误", f"无法加载图片 {image_path}：{e}")

# 第14个窗口（R(P)）
class FourteenthWindow(tk.Toplevel):
    def __init__(self, root, image_directory):
        super().__init__(root)
        self.title("R(A))")
        self.geometry("1350x900")

        self.row = 0
        self.col = 0

        # 获取指定文件夹中所有符合条件的图片文件
        image_files = [f for f in os.listdir(image_directory) if f.lower().endswith(('.png', '.tif'))]
        image_paths = [os.path.join(image_directory, f) for f in image_files]

        for image_path in image_paths:
            try:
                # 打开图片并调整大小（如果需要）
                image = Image.open(image_path)
                image.thumbnail((400, 400))  # 这里将图片大小调整为200x200，您可以根据需要调整

                # 转换为tkinter可以显示的格式
                photo = ImageTk.PhotoImage(image)

                # 创建一个Label控件来显示图片，并使用grid布局
                label = ttk.Label(self, image=photo)
                label.image = photo  # 保持对PhotoImage的引用，防止被垃圾回收
                label.grid(row=self.row, column=self.col, padx=10, pady=10)

                # 更新行列索引
                self.col += 1
                if self.col >= 3:  # 这里设置每行显示4张图片，您可以根据需要调整
                    self.col = 0
                    self.row += 1

            except Exception as e:
                # 显示错误消息框
                messagebox.showerror("图片加载错误", f"无法加载图片 {image_path}：{e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = MainApp(root)
    root.mainloop()
